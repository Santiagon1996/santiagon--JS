// ENTREGA N1
// let precioFernet = 1750
// let precioCerveza = 500
// let precioVino = 1000
// let precioDestilados = 2000
//  let carrito = Number("");
//  let compraTotal = Number("");
//  let volver=  ""

// do {
//     let estanteria = Number(prompt(`Ingrese una opcion : \n-1 Comprar vino: $` + precioVino + ` \n -2 Comprar cerveza: $` + precioCerveza + `\n -3 Comprar destilados: $` + precioDestilados + `\n -4 Fernet: $ ` + precioFernet + `\n -0 Volver al inicio \n -9 Volver a comprar: si/no `))
//     if (estanteria == 1) {
//         alert("Acaba de agregar la opcion Vino a su carrito")
//         carrito = Number(prompt("El valor de su compra es de " + precioVino + " Cuantos articulos desea comprar?"))
//         compraTotal = alert("Valor de compra es de " + precioVino + " con un valor de $ " + multiplicacion(carrito, precioVino))

//     } else if (estanteria == 2) {
//         alert("Acaba de agregar la opcion Cerveza a su carrito")
//         carrito = Number(prompt("El valor de su compra es de " + precioCerveza + " Cuantos articulos desea comprar?"))
//         compraTotal = alert("Valor de compra es de " + precioCerveza + " con un valor de $ " + multiplicacion(carrito, precioCerveza))

//     } else if (estanteria == 3) {
//         alert("Acaba de agregar la opcion Destilados a su carrito")
//         carrito = Number(prompt("El valor de su compra es de " + precioDestilados + " Cuantos articulos desea comprar?"))
//         compraTotal = alert("Valor de compra es de " + precioDestilados + " con un valor de $ " + multiplicacion(carrito, precioDestilados))

//     } else if (estanteria == 4) {
//         alert("Aacaba de agregar la opcion Fernet a su carrito")
//         carrito = Number(prompt("El valor de su compra es de " + precioFernet + " Cuantos articulos desea comprar?"))
//         compraTotal = alert("Valor de compra es de " + precioFernet + " con un valor de $ " + multiplicacion(carrito, precioFernet))
//     } else if (estanteria ==0 ) {
//       alert("Volver al inicio")
//       break;
//     } else if(estanteria==9){
//          volver = prompt("Desea seguir comprando : \n -SI \n -NO")      
//     }    
// } while (volver !== "no");


// function multiplicacion(numero1, numero2,) {
//     let MultiEstanteria = numero1 * numero2
//     return MultiEstanteria
// }









//ENTREGA N2

const bebidas = [
    { nombre: "Fernet", precio: 1750 },
    { nombre: "Cerveza", precio: 500 },
    { nombre: "Vino", precio: 1000 },
    { nombre: "Destilados", precio: 2000 }
]

let carritoDeCompra = []

let volver=  ""

function multiplicacion(numero1, numero2,) {
    let MultiEstanteria = numero1 * numero2
    return MultiEstanteria
} 

do {
    let estanteria = Number(prompt("Bienvenido a tu compras online de bebidas, desea comprar un producto, elija un numero 1 o 2 : \n 1) SI \n 2) NO "))
    if (estanteria != 1 && estanteria != 2) {
        alert("Ingrese una opcion valida ")
        estanteria = Number(prompt("Bienvenido a tu compras online de bebidas, desea comprar un producto, elija las opciones 1 o 2 : \n 1) SI \n 2) NO"))
    }
    else if (estanteria == 1) {
        alert("A continuacion nuestra lista de bebidas")
        let misBebidas = bebidas.map((bebida) => bebida.nombre + " " + bebida.precio + "$")
        alert(misBebidas.join(" / "))
        while (estanteria != 2) {
            let bebida = prompt("Agrega una bebida a tu compra!!")
            let precio = 0
            if (bebida == "Fernet" || bebida == "Cerveza" || bebida == "Vino" || bebida == "Destilados") {
                switch (bebida) {
                    case "Fernet":
                        precio = 1750
                        break
                    case "Cerveza":
                        precio = 500
                        break
                    case "Vino":
                        precio = 1000
                        break
                    case "Destilados":
                        precio = 2000
                        break
                    default:
                        break
                }
                let cantidad = Number(prompt("Cuantas unidades quiere adquirir"))
                carritoDeCompra.push({ bebida, cantidad, precio })
            } else {
                alert("No encontrasmos el producto dentro de nuestra estanteria")
            }
            estanteria = prompt("Quiere agregar alguna bebida mas? \n elija un numero 1 o 2 : \n 1) SI \n 2) NO")
            while (estanteria == 2) {
                alert("Gracias por sus compras, hasta la proxima")
                carritoDeCompra.map((compraFinal) => {
                    alert(`Bebida: ${compraFinal.bebida}, unidades: ${compraFinal.cantidad}, total: ${multiplicacion(compraFinal.cantidad, compraFinal.precio)}`)
                })
                break
            }

        }
    }else if (estanteria == 2) {
        volver = prompt("Desea seguir comprando : \n -SI \n -NO")
        }
    } while (volver == "no");

const total = carritoDeCompra.reduce((acc, el)=> acc + multiplicacion(el.precio , el.unidades), 0)
console.log(`Su total a pagar es de ${total}`)


























//     else if (estanteria == 2) {
//         alert("Gracias por visitar nuestro sitio, hasta pronto!!")

//     }
//     else if (estanteria == 4) {
//         alert("Aacaba de agregar la opcion Fernet a su carrito")
//         carrito = Number(prompt("El valor de su compra es de " + precioFernet + " Cuantos articulos desea comprar?"))
//         compraTotal = alert("Valor de compra es de " + precioFernet + " con un valor de $ " + multiplicacion(carrito, precioFernet))
//     } else if (estanteria == 0) {
//         alert("Volver al inicio")
//         break;
//     } else if (estanteria == 9) {
//          volver = prompt("Desea seguir comprando : \n -SI \n -NO")
//      }
  